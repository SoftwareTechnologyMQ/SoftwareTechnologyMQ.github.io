
public class  Operator {
    public static void main(String[] args) {
        int a = 10;
        int b = 20;
        int c = smaller(a, b);

        System.out.println("smaller of 10, 20 is "+c);

        System.out.println("smallest of 50, 30, 90, 60 is "+smaller(smaller(50, 30), smaller(90, 60)));
    }

    /**
     * 
     * @param x
     * @param y
     * @return the smaller of the two values passed
     */
    public static int smaller(int x, int y) {
        if(x < y) {
            return x;
        }
        else {
            return y;
        }
    }  
}