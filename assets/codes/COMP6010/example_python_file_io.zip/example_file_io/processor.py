import unittest

def read(filename):
    students = [] # empty list
    grades = [] # empty list
    with open(filename, 'r') as f:
        header = f.readline().strip().split(",") # first line has weights
        weights = [int(x) for x in header[1:]] # split into integers (exclude first empty value)
        for line in f:
            tokens = line.strip().split(",")
            students.append(tokens[0]) # first value is the name
            grades.append([int(item) for item in tokens[1:]]) # rest are the marks
    return weights, students, grades # pack and return all three

def get_totals(students, weights, marks):
    totals = {} # dictionary for student, total mapping
    for i in range(len(students)):
        total = 0
        for j in range(len(weights)): # add up all the weighted marks
            total += weights[j] * marks[i][j] / 100
        totals[students[i]] = int(total+0.5) # nice way of rounding off to nearest integer
    return totals

def grade(total):
    if total >= 85:
        return 'HD'
    elif total >= 75:
        return 'D'
    elif total >= 65:
        return 'CR'
    elif total >= 50:
        return 'P'
    else:
        return 'F'

def write(totals, filename):
    with open(filename, 'w') as f:
        f.write("Name,Total,Grade\n")
        for name, total in totals.items():
            f.write(name + ',' + str(total) + ',' + grade(total) + '\n')

if __name__ == '__main__':
    weights, names, marks = read("input.csv") # unpack returned tuple
    totals = get_totals(names, weights, marks)
    write(totals, "output.csv")
    print("students:",names)
    print("assessment weights:",weights)
    print("assessment marks:",marks)
    print("assessment marks:",marks)
    print("final marks:",totals)
